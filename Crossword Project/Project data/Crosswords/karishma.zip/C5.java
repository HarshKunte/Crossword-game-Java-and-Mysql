package com.myproject.UI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class C5 {

	private JFrame frame;
	private JTextField textField;
	private JTextField txtO;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField txtR;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField txtK;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField txtD;
	private JTextField txtM;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField txtT;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField txtC;
	private JTextField txtE_2;
	private JTextField txtL;
	private JTextField txtE_1;
	private JTextField txtR_1;
	private JTextField txtO_1;
	private JTextField txtN;
	private JTextField txtC_1;
	private JTextField txtC_2;
	private JTextField textField_32;
	private JTextField textField_33;
	private JTextField textField_34;
	private JTextField textField_35;
	private JTextField textField_36;
	private JTextField textField_37;
	private JTextField textField_38;
	private JTextField txtE;
	private JTextField textField_40;
	private JTextField txtA;
	private JTextField textField_42;
	private JTextField textField_43;
	private JTextField textField_44;
	private JTextField textField_45;
	private JTextField textField_46;
	private JTextField textField_47;
	private JTextField txtP;
	private JTextField textField_49;
	private JTextField textField_50;
	private JTextField textField_51;
	private JTextField textField_52;
	private JTextField txtI;
	private JTextField textField_54;
	private JTextField textField_55;
	private JTextField textField_56;
	private JTextField textField_57;
	private JTextField textField_58;
	private JTextField textField_59;
	private JTextField txtY;
	private JTextField textField_61;
	private JTextField textField_62;
	private JTextField txtR_2;
	private JTextField textField_64;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JPanel panel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					C5 window = new C5();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public C5() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1560, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBackground(Color.WHITE);
		textField.setBounds(447, 13, 42, 42);
		frame.getContentPane().add(textField);
		
		txtO = new JTextField();
		txtO.setEnabled(false);
		txtO.setText(" O");
		txtO.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtO.setColumns(10);
		txtO.setBackground(Color.WHITE);
		txtO.setBounds(447, 54, 42, 42);
		frame.getContentPane().add(txtO);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBackground(Color.WHITE);
		textField_2.setBounds(405, 54, 42, 42);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBackground(Color.WHITE);
		textField_3.setBounds(487, 54, 42, 42);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBackground(Color.WHITE);
		textField_4.setBounds(529, 54, 42, 42);
		frame.getContentPane().add(textField_4);
		
		txtR = new JTextField();
		txtR.setEnabled(false);
		txtR.setText(" R");
		txtR.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtR.setColumns(10);
		txtR.setBackground(Color.WHITE);
		txtR.setBounds(571, 54, 42, 42);
		frame.getContentPane().add(txtR);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBackground(Color.WHITE);
		textField_6.setBounds(613, 54, 42, 42);
		frame.getContentPane().add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBackground(Color.WHITE);
		textField_7.setBounds(656, 54, 42, 42);
		frame.getContentPane().add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBackground(Color.WHITE);
		textField_8.setBounds(697, 54, 42, 42);
		frame.getContentPane().add(textField_8);
		
		txtK = new JTextField();
		txtK.setEnabled(false);
		txtK.setText(" K");
		txtK.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtK.setColumns(10);
		txtK.setBackground(Color.WHITE);
		txtK.setBounds(737, 54, 42, 42);
		frame.getContentPane().add(txtK);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBackground(Color.WHITE);
		textField_10.setBounds(737, 96, 42, 42);
		frame.getContentPane().add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBackground(Color.WHITE);
		textField_11.setBounds(737, 135, 42, 42);
		frame.getContentPane().add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		textField_12.setBackground(Color.WHITE);
		textField_12.setBounds(737, 177, 42, 42);
		frame.getContentPane().add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setColumns(10);
		textField_13.setBackground(Color.WHITE);
		textField_13.setBounds(737, 218, 42, 42);
		frame.getContentPane().add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setColumns(10);
		textField_14.setBackground(Color.WHITE);
		textField_14.setBounds(737, 259, 42, 42);
		frame.getContentPane().add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setColumns(10);
		textField_15.setBackground(Color.WHITE);
		textField_15.setBounds(737, 299, 42, 42);
		frame.getContentPane().add(textField_15);
		
		txtD = new JTextField();
		txtD.setEnabled(false);
		txtD.setText(" D");
		txtD.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtD.setColumns(10);
		txtD.setBackground(Color.WHITE);
		txtD.setBounds(737, 339, 42, 42);
		frame.getContentPane().add(txtD);
		
		txtM = new JTextField();
		txtM.setEnabled(false);
		txtM.setText(" M");
		txtM.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtM.setColumns(10);
		txtM.setBackground(Color.WHITE);
		txtM.setBounds(447, 96, 42, 42);
		frame.getContentPane().add(txtM);
		
		textField_18 = new JTextField();
		textField_18.setColumns(10);
		textField_18.setBackground(Color.WHITE);
		textField_18.setBounds(447, 135, 42, 42);
		frame.getContentPane().add(textField_18);
		
		textField_19 = new JTextField();
		textField_19.setColumns(10);
		textField_19.setBackground(Color.WHITE);
		textField_19.setBounds(447, 177, 42, 42);
		frame.getContentPane().add(textField_19);
		
		txtT = new JTextField();
		txtT.setEnabled(false);
		txtT.setText(" T");
		txtT.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtT.setColumns(10);
		txtT.setBackground(Color.WHITE);
		txtT.setBounds(447, 218, 42, 42);
		frame.getContentPane().add(txtT);
		
		textField_21 = new JTextField();
		textField_21.setColumns(10);
		textField_21.setBackground(Color.WHITE);
		textField_21.setBounds(447, 259, 42, 42);
		frame.getContentPane().add(textField_21);
		
		textField_22 = new JTextField();
		textField_22.setColumns(10);
		textField_22.setBackground(Color.WHITE);
		textField_22.setBounds(447, 299, 42, 42);
		frame.getContentPane().add(textField_22);
		
		txtC = new JTextField();
		txtC.setEnabled(false);
		txtC.setText(" C");
		txtC.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtC.setColumns(10);
		txtC.setBackground(Color.WHITE);
		txtC.setBounds(405, 218, 42, 42);
		frame.getContentPane().add(txtC);
		
		txtE_2 = new JTextField();
		txtE_2.setEnabled(false);
		txtE_2.setText(" E");
		txtE_2.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtE_2.setColumns(10);
		txtE_2.setBackground(Color.WHITE);
		txtE_2.setBounds(363, 218, 42, 42);
		frame.getContentPane().add(txtE_2);
		
		txtL = new JTextField();
		txtL.setEnabled(false);
		txtL.setText(" L");
		txtL.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtL.setColumns(10);
		txtL.setBackground(Color.WHITE);
		txtL.setBounds(321, 218, 42, 42);
		frame.getContentPane().add(txtL);
		
		txtE_1 = new JTextField();
		txtE_1.setEnabled(false);
		txtE_1.setText(" E");
		txtE_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtE_1.setColumns(10);
		txtE_1.setBackground(Color.WHITE);
		txtE_1.setBounds(281, 218, 42, 42);
		frame.getContentPane().add(txtE_1);
		
		txtR_1 = new JTextField();
		txtR_1.setEnabled(false);
		txtR_1.setText(" R");
		txtR_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtR_1.setColumns(10);
		txtR_1.setBackground(Color.WHITE);
		txtR_1.setBounds(487, 218, 42, 42);
		frame.getContentPane().add(txtR_1);
		
		txtO_1 = new JTextField();
		txtO_1.setEnabled(false);
		txtO_1.setText(" O");
		txtO_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtO_1.setColumns(10);
		txtO_1.setBackground(Color.WHITE);
		txtO_1.setBounds(529, 218, 42, 42);
		frame.getContentPane().add(txtO_1);
		
		txtN = new JTextField();
		txtN.setEnabled(false);
		txtN.setText(" N");
		txtN.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtN.setColumns(10);
		txtN.setBackground(Color.WHITE);
		txtN.setBounds(571, 218, 42, 42);
		frame.getContentPane().add(txtN);
		
		txtC_1 = new JTextField();
		txtC_1.setEnabled(false);
		txtC_1.setText(" I");
		txtC_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtC_1.setColumns(10);
		txtC_1.setBackground(Color.WHITE);
		txtC_1.setBounds(613, 218, 42, 42);
		frame.getContentPane().add(txtC_1);
		
		txtC_2 = new JTextField();
		txtC_2.setEnabled(false);
		txtC_2.setText(" C");
		txtC_2.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtC_2.setColumns(10);
		txtC_2.setBackground(Color.WHITE);
		txtC_2.setBounds(656, 218, 42, 42);
		frame.getContentPane().add(txtC_2);
		
		textField_32 = new JTextField();
		textField_32.setColumns(10);
		textField_32.setBackground(Color.WHITE);
		textField_32.setBounds(529, 177, 42, 42);
		frame.getContentPane().add(textField_32);
		
		textField_33 = new JTextField();
		textField_33.setColumns(10);
		textField_33.setBackground(Color.WHITE);
		textField_33.setBounds(529, 259, 42, 42);
		frame.getContentPane().add(textField_33);
		
		textField_34 = new JTextField();
		textField_34.setColumns(10);
		textField_34.setBackground(Color.WHITE);
		textField_34.setBounds(529, 299, 42, 42);
		frame.getContentPane().add(textField_34);
		
		textField_35 = new JTextField();
		textField_35.setColumns(10);
		textField_35.setBackground(Color.WHITE);
		textField_35.setBounds(529, 339, 42, 42);
		frame.getContentPane().add(textField_35);
		
		textField_36 = new JTextField();
		textField_36.setColumns(10);
		textField_36.setBackground(Color.WHITE);
		textField_36.setBounds(529, 380, 42, 42);
		frame.getContentPane().add(textField_36);
		
		textField_37 = new JTextField();
		textField_37.setColumns(10);
		textField_37.setBackground(Color.WHITE);
		textField_37.setBounds(656, 259, 42, 42);
		frame.getContentPane().add(textField_37);
		
		textField_38 = new JTextField();
		textField_38.setColumns(10);
		textField_38.setBackground(Color.WHITE);
		textField_38.setBounds(656, 299, 42, 42);
		frame.getContentPane().add(textField_38);
		
		txtE = new JTextField();
		txtE.setEnabled(false);
		txtE.setText(" E");
		txtE.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtE.setColumns(10);
		txtE.setBackground(Color.WHITE);
		txtE.setBounds(656, 339, 42, 42);
		frame.getContentPane().add(txtE);
		
		textField_40 = new JTextField();
		textField_40.setColumns(10);
		textField_40.setBackground(Color.WHITE);
		textField_40.setBounds(656, 380, 42, 42);
		frame.getContentPane().add(textField_40);
		
		txtA = new JTextField();
		txtA.setEnabled(false);
		txtA.setText(" A");
		txtA.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtA.setColumns(10);
		txtA.setBackground(Color.WHITE);
		txtA.setBounds(656, 423, 42, 42);
		frame.getContentPane().add(txtA);
		
		textField_42 = new JTextField();
		textField_42.setColumns(10);
		textField_42.setBackground(Color.WHITE);
		textField_42.setBounds(697, 339, 42, 42);
		frame.getContentPane().add(textField_42);
		
		textField_43 = new JTextField();
		textField_43.setColumns(10);
		textField_43.setBackground(Color.WHITE);
		textField_43.setBounds(613, 339, 42, 42);
		frame.getContentPane().add(textField_43);
		
		textField_44 = new JTextField();
		textField_44.setColumns(10);
		textField_44.setBackground(Color.WHITE);
		textField_44.setBounds(613, 423, 42, 42);
		frame.getContentPane().add(textField_44);
		
		textField_45 = new JTextField();
		textField_45.setColumns(10);
		textField_45.setBackground(Color.WHITE);
		textField_45.setBounds(697, 423, 42, 42);
		frame.getContentPane().add(textField_45);
		
		textField_46 = new JTextField();
		textField_46.setColumns(10);
		textField_46.setBackground(Color.WHITE);
		textField_46.setBounds(737, 423, 42, 42);
		frame.getContentPane().add(textField_46);
		
		textField_47 = new JTextField();
		textField_47.setColumns(10);
		textField_47.setBackground(Color.WHITE);
		textField_47.setBounds(779, 423, 42, 42);
		frame.getContentPane().add(textField_47);
		
		txtP = new JTextField();
		txtP.setEnabled(false);
		txtP.setText(" P");
		txtP.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtP.setColumns(10);
		txtP.setBackground(Color.WHITE);
		txtP.setBounds(822, 423, 42, 42);
		frame.getContentPane().add(txtP);
		
		textField_49 = new JTextField();
		textField_49.setColumns(10);
		textField_49.setBackground(Color.WHITE);
		textField_49.setBounds(363, 177, 42, 42);
		frame.getContentPane().add(textField_49);
		
		textField_50 = new JTextField();
		textField_50.setColumns(10);
		textField_50.setBackground(Color.WHITE);
		textField_50.setBounds(363, 259, 42, 42);
		frame.getContentPane().add(textField_50);
		
		textField_51 = new JTextField();
		textField_51.setColumns(10);
		textField_51.setBackground(Color.WHITE);
		textField_51.setBounds(363, 299, 42, 42);
		frame.getContentPane().add(textField_51);
		
		textField_52 = new JTextField();
		textField_52.setColumns(10);
		textField_52.setBackground(Color.WHITE);
		textField_52.setBounds(363, 339, 42, 42);
		frame.getContentPane().add(textField_52);
		
		txtI = new JTextField();
		txtI.setEnabled(false);
		txtI.setText(" I");
		txtI.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtI.setColumns(10);
		txtI.setBackground(Color.WHITE);
		txtI.setBounds(363, 380, 42, 42);
		frame.getContentPane().add(txtI);
		
		textField_54 = new JTextField();
		textField_54.setColumns(10);
		textField_54.setBackground(Color.WHITE);
		textField_54.setBounds(363, 423, 42, 42);
		frame.getContentPane().add(textField_54);
		
		textField_55 = new JTextField();
		textField_55.setColumns(10);
		textField_55.setBackground(Color.WHITE);
		textField_55.setBounds(363, 466, 42, 42);
		frame.getContentPane().add(textField_55);
		
		textField_56 = new JTextField();
		textField_56.setColumns(10);
		textField_56.setBackground(Color.WHITE);
		textField_56.setBounds(281, 177, 42, 42);
		frame.getContentPane().add(textField_56);
		
		textField_57 = new JTextField();
		textField_57.setColumns(10);
		textField_57.setBackground(Color.WHITE);
		textField_57.setBounds(281, 259, 42, 42);
		frame.getContentPane().add(textField_57);
		
		textField_58 = new JTextField();
		textField_58.setColumns(10);
		textField_58.setBackground(Color.WHITE);
		textField_58.setBounds(281, 299, 42, 42);
		frame.getContentPane().add(textField_58);
		
		textField_59 = new JTextField();
		textField_59.setColumns(10);
		textField_59.setBackground(Color.WHITE);
		textField_59.setBounds(281, 339, 42, 42);
		frame.getContentPane().add(textField_59);
		
		txtY = new JTextField();
		txtY.setEnabled(false);
		txtY.setText(" Y");
		txtY.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtY.setColumns(10);
		txtY.setBackground(Color.WHITE);
		txtY.setBounds(281, 380, 42, 42);
		frame.getContentPane().add(txtY);
		
		textField_61 = new JTextField();
		textField_61.setColumns(10);
		textField_61.setBackground(Color.WHITE);
		textField_61.setBounds(281, 423, 42, 42);
		frame.getContentPane().add(textField_61);
		
		textField_62 = new JTextField();
		textField_62.setColumns(10);
		textField_62.setBackground(Color.WHITE);
		textField_62.setBounds(281, 466, 42, 42);
		frame.getContentPane().add(textField_62);
		
		txtR_2 = new JTextField();
		txtR_2.setEnabled(false);
		txtR_2.setText(" R");
		txtR_2.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtR_2.setColumns(10);
		txtR_2.setBackground(Color.WHITE);
		txtR_2.setBounds(281, 505, 42, 42);
		frame.getContentPane().add(txtR_2);
		
		textField_64 = new JTextField();
		textField_64.setColumns(10);
		textField_64.setBackground(Color.WHITE);
		textField_64.setBounds(281, 547, 42, 42);
		frame.getContentPane().add(textField_64);
		
		JButton btnFinish = new JButton("FINISH");
		btnFinish.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnFinish.setBounds(363, 681, 191, 42);
		frame.getContentPane().add(btnFinish);
		
		JButton btnGiveUp = new JButton("GIVE UP!");
		btnGiveUp.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnGiveUp.setBounds(656, 681, 167, 42);
		frame.getContentPane().add(btnGiveUp);
		
		label = new JLabel("1");
		label.setBounds(432, 13, 15, 16);
		frame.getContentPane().add(label);
		
		label_1 = new JLabel("2");
		label_1.setBounds(390, 68, 15, 16);
		frame.getContentPane().add(label_1);
		
		label_2 = new JLabel("3");
		label_2.setBounds(747, 26, 15, 16);
		frame.getContentPane().add(label_2);
		
		label_3 = new JLabel("4");
		label_3.setBounds(292, 161, 15, 16);
		frame.getContentPane().add(label_3);
		
		label_4 = new JLabel("5");
		label_4.setBounds(375, 161, 15, 16);
		frame.getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("6");
		label_5.setBounds(539, 161, 15, 16);
		frame.getContentPane().add(label_5);
		
		JLabel label_6 = new JLabel("7");
		label_6.setBounds(594, 353, 15, 16);
		frame.getContentPane().add(label_6);
		
		JLabel label_7 = new JLabel("8");
		label_7.setBounds(598, 437, 15, 16);
		frame.getContentPane().add(label_7);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Manasi Malkar\\Desktop\\IMG-20180812-elec.jpg"));
		lblNewLabel.setBounds(985, 48, 326, 212);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Manasi Malkar\\Desktop\\IMG-20180812-elec2.jpg"));
		lblNewLabel_1.setLabelFor(frame);
		lblNewLabel_1.setBounds(995, 237, 538, 289);
		frame.getContentPane().add(lblNewLabel_1);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 1555, 1033);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
	}
}
