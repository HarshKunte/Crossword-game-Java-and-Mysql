package com.myproject.UI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;

public class C11 {

	private JFrame frame;
	private JTextField textField;
	private JTextField txtS;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField txtL;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField txtE;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField txtR;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField textField_33;
	private JTextField textField_34;
	private JTextField textField_35;
	private JTextField textField_36;
	private JTextField textField_37;
	private JTextField textField_38;
	private JTextField textField_39;
	private JTextField textField_40;
	private JTextField textField_41;
	private JTextField textField_42;
	private JTextField textField_43;
	private JTextField textField_44;
	private JTextField textField_45;
	private JTextField textField_46;
	private JTextField txtR_1;
	private JTextField textField_48;
	private JTextField textField_49;
	private JTextField textField_50;
	private JTextField textField_51;
	private JTextField textField_52;
	private JTextField textField_53;
	private JTextField textField_54;
	private JTextField textField_55;
	private JTextField textField_56;
	private JTextField textField_57;
	private JTextField textField_58;
	private JTextField txtE_1;
	private JTextField textField_60;
	private JTextField textField_61;
	private JTextField txtS_1;
	private JTextField textField_63;
	private JTextField textField_64;
	private JTextField textField_65;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					C11 window = new C11();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public C11() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1338, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField.setColumns(10);
		textField.setBounds(539, 104, 42, 43);
		frame.getContentPane().add(textField);
		
		txtS = new JTextField();
		txtS.setEnabled(false);
		txtS.setText(" S");
		txtS.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtS.setColumns(10);
		txtS.setBounds(539, 62, 42, 43);
		frame.getContentPane().add(txtS);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_2.setColumns(10);
		textField_2.setBounds(539, 147, 42, 43);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_3.setColumns(10);
		textField_3.setBounds(539, 190, 42, 43);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_4.setColumns(10);
		textField_4.setBounds(539, 233, 42, 43);
		frame.getContentPane().add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_5.setColumns(10);
		textField_5.setBounds(539, 276, 42, 43);
		frame.getContentPane().add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_6.setColumns(10);
		textField_6.setBounds(539, 318, 42, 43);
		frame.getContentPane().add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_7.setColumns(10);
		textField_7.setBounds(539, 361, 42, 43);
		frame.getContentPane().add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_8.setColumns(10);
		textField_8.setBounds(497, 190, 42, 43);
		frame.getContentPane().add(textField_8);
		
		txtL = new JTextField();
		txtL.setEnabled(false);
		txtL.setText(" L");
		txtL.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtL.setColumns(10);
		txtL.setBounds(455, 190, 42, 43);
		frame.getContentPane().add(txtL);
		
		textField_10 = new JTextField();
		textField_10.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_10.setColumns(10);
		textField_10.setBounds(412, 190, 42, 43);
		frame.getContentPane().add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_11.setColumns(10);
		textField_11.setBounds(369, 190, 42, 43);
		frame.getContentPane().add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_12.setColumns(10);
		textField_12.setBounds(455, 147, 42, 43);
		frame.getContentPane().add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_13.setColumns(10);
		textField_13.setBounds(455, 104, 42, 43);
		frame.getContentPane().add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_14.setColumns(10);
		textField_14.setBounds(455, 62, 42, 43);
		frame.getContentPane().add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_15.setColumns(10);
		textField_15.setBounds(455, 233, 42, 43);
		frame.getContentPane().add(textField_15);
		
		textField_16 = new JTextField();
		textField_16.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_16.setColumns(10);
		textField_16.setBounds(455, 276, 42, 43);
		frame.getContentPane().add(textField_16);
		
		textField_17 = new JTextField();
		textField_17.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_17.setColumns(10);
		textField_17.setBounds(369, 233, 42, 43);
		frame.getContentPane().add(textField_17);
		
		textField_18 = new JTextField();
		textField_18.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_18.setColumns(10);
		textField_18.setBounds(369, 276, 42, 43);
		frame.getContentPane().add(textField_18);
		
		textField_19 = new JTextField();
		textField_19.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_19.setColumns(10);
		textField_19.setBounds(369, 318, 42, 43);
		frame.getContentPane().add(textField_19);
		
		textField_20 = new JTextField();
		textField_20.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_20.setColumns(10);
		textField_20.setBounds(369, 361, 42, 43);
		frame.getContentPane().add(textField_20);
		
		textField_21 = new JTextField();
		textField_21.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_21.setColumns(10);
		textField_21.setBounds(369, 404, 42, 43);
		frame.getContentPane().add(textField_21);
		
		textField_22 = new JTextField();
		textField_22.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_22.setColumns(10);
		textField_22.setBounds(369, 447, 42, 43);
		frame.getContentPane().add(textField_22);
		
		textField_23 = new JTextField();
		textField_23.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_23.setColumns(10);
		textField_23.setBounds(369, 491, 42, 43);
		frame.getContentPane().add(textField_23);
		
		txtE = new JTextField();
		txtE.setEnabled(false);
		txtE.setText(" E");
		txtE.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtE.setColumns(10);
		txtE.setBounds(369, 535, 42, 43);
		frame.getContentPane().add(txtE);
		
		textField_25 = new JTextField();
		textField_25.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_25.setColumns(10);
		textField_25.setBounds(369, 577, 42, 43);
		frame.getContentPane().add(textField_25);
		
		textField_26 = new JTextField();
		textField_26.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_26.setColumns(10);
		textField_26.setBounds(327, 404, 42, 43);
		frame.getContentPane().add(textField_26);
		
		textField_27 = new JTextField();
		textField_27.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_27.setColumns(10);
		textField_27.setBounds(412, 404, 42, 43);
		frame.getContentPane().add(textField_27);
		
		textField_28 = new JTextField();
		textField_28.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_28.setColumns(10);
		textField_28.setBounds(285, 404, 42, 43);
		frame.getContentPane().add(textField_28);
		
		txtR = new JTextField();
		txtR.setEnabled(false);
		txtR.setText(" R");
		txtR.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtR.setColumns(10);
		txtR.setBounds(242, 404, 42, 43);
		frame.getContentPane().add(txtR);
		
		textField_30 = new JTextField();
		textField_30.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_30.setColumns(10);
		textField_30.setBounds(200, 404, 42, 43);
		frame.getContentPane().add(textField_30);
		
		textField_31 = new JTextField();
		textField_31.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_31.setColumns(10);
		textField_31.setBounds(157, 404, 42, 43);
		frame.getContentPane().add(textField_31);
		
		textField_32 = new JTextField();
		textField_32.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_32.setColumns(10);
		textField_32.setBounds(114, 404, 42, 43);
		frame.getContentPane().add(textField_32);
		
		textField_33 = new JTextField();
		textField_33.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_33.setColumns(10);
		textField_33.setBounds(114, 361, 42, 43);
		frame.getContentPane().add(textField_33);
		
		textField_34 = new JTextField();
		textField_34.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_34.setColumns(10);
		textField_34.setBounds(114, 318, 42, 43);
		frame.getContentPane().add(textField_34);
		
		textField_35 = new JTextField();
		textField_35.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_35.setColumns(10);
		textField_35.setBounds(114, 447, 42, 43);
		frame.getContentPane().add(textField_35);
		
		textField_36 = new JTextField();
		textField_36.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_36.setColumns(10);
		textField_36.setBounds(114, 491, 42, 43);
		frame.getContentPane().add(textField_36);
		
		textField_37 = new JTextField();
		textField_37.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_37.setColumns(10);
		textField_37.setBounds(114, 535, 42, 43);
		frame.getContentPane().add(textField_37);
		
		textField_38 = new JTextField();
		textField_38.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_38.setColumns(10);
		textField_38.setBounds(327, 535, 42, 43);
		frame.getContentPane().add(textField_38);
		
		textField_39 = new JTextField();
		textField_39.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_39.setColumns(10);
		textField_39.setBounds(285, 535, 42, 43);
		frame.getContentPane().add(textField_39);
		
		textField_40 = new JTextField();
		textField_40.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_40.setColumns(10);
		textField_40.setBounds(242, 535, 42, 43);
		frame.getContentPane().add(textField_40);
		
		textField_41 = new JTextField();
		textField_41.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_41.setColumns(10);
		textField_41.setBounds(412, 535, 42, 43);
		frame.getContentPane().add(textField_41);
		
		textField_42 = new JTextField();
		textField_42.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_42.setColumns(10);
		textField_42.setBounds(455, 535, 42, 43);
		frame.getContentPane().add(textField_42);
		
		textField_43 = new JTextField();
		textField_43.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_43.setColumns(10);
		textField_43.setBounds(497, 535, 42, 43);
		frame.getContentPane().add(textField_43);
		
		textField_44 = new JTextField();
		textField_44.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_44.setColumns(10);
		textField_44.setBounds(539, 535, 42, 43);
		frame.getContentPane().add(textField_44);
		
		textField_45 = new JTextField();
		textField_45.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_45.setColumns(10);
		textField_45.setBounds(582, 535, 42, 43);
		frame.getContentPane().add(textField_45);
		
		textField_46 = new JTextField();
		textField_46.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_46.setColumns(10);
		textField_46.setBounds(582, 318, 42, 43);
		frame.getContentPane().add(textField_46);
		
		txtR_1 = new JTextField();
		txtR_1.setEnabled(false);
		txtR_1.setText(" R");
		txtR_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtR_1.setColumns(10);
		txtR_1.setBounds(624, 318, 42, 43);
		frame.getContentPane().add(txtR_1);
		
		textField_48 = new JTextField();
		textField_48.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_48.setColumns(10);
		textField_48.setBounds(666, 318, 42, 43);
		frame.getContentPane().add(textField_48);
		
		textField_49 = new JTextField();
		textField_49.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_49.setColumns(10);
		textField_49.setBounds(624, 276, 42, 43);
		frame.getContentPane().add(textField_49);
		
		textField_50 = new JTextField();
		textField_50.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_50.setColumns(10);
		textField_50.setBounds(624, 233, 42, 43);
		frame.getContentPane().add(textField_50);
		
		textField_51 = new JTextField();
		textField_51.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_51.setColumns(10);
		textField_51.setBounds(624, 190, 42, 43);
		frame.getContentPane().add(textField_51);
		
		textField_52 = new JTextField();
		textField_52.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_52.setColumns(10);
		textField_52.setBounds(624, 147, 42, 43);
		frame.getContentPane().add(textField_52);
		
		textField_53 = new JTextField();
		textField_53.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_53.setColumns(10);
		textField_53.setBounds(624, 104, 42, 43);
		frame.getContentPane().add(textField_53);
		
		textField_54 = new JTextField();
		textField_54.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_54.setColumns(10);
		textField_54.setBounds(624, 361, 42, 43);
		frame.getContentPane().add(textField_54);
		
		textField_55 = new JTextField();
		textField_55.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_55.setColumns(10);
		textField_55.setBounds(624, 404, 42, 43);
		frame.getContentPane().add(textField_55);
		
		textField_56 = new JTextField();
		textField_56.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_56.setColumns(10);
		textField_56.setBounds(624, 447, 42, 43);
		frame.getContentPane().add(textField_56);
		
		textField_57 = new JTextField();
		textField_57.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_57.setColumns(10);
		textField_57.setBounds(582, 447, 42, 43);
		frame.getContentPane().add(textField_57);
		
		textField_58 = new JTextField();
		textField_58.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_58.setColumns(10);
		textField_58.setBounds(666, 447, 42, 43);
		frame.getContentPane().add(textField_58);
		
		txtE_1 = new JTextField();
		txtE_1.setEnabled(false);
		txtE_1.setText(" E");
		txtE_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtE_1.setColumns(10);
		txtE_1.setBounds(709, 447, 42, 43);
		frame.getContentPane().add(txtE_1);
		
		textField_60 = new JTextField();
		textField_60.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_60.setColumns(10);
		textField_60.setBounds(752, 447, 42, 43);
		frame.getContentPane().add(textField_60);
		
		textField_61 = new JTextField();
		textField_61.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_61.setColumns(10);
		textField_61.setBounds(666, 233, 42, 43);
		frame.getContentPane().add(textField_61);
		
		txtS_1 = new JTextField();
		txtS_1.setEnabled(false);
		txtS_1.setText(" S");
		txtS_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtS_1.setColumns(10);
		txtS_1.setBounds(709, 233, 42, 43);
		frame.getContentPane().add(txtS_1);
		
		textField_63 = new JTextField();
		textField_63.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_63.setColumns(10);
		textField_63.setBounds(752, 233, 42, 43);
		frame.getContentPane().add(textField_63);
		
		textField_64 = new JTextField();
		textField_64.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_64.setColumns(10);
		textField_64.setBounds(794, 233, 42, 43);
		frame.getContentPane().add(textField_64);
		
		textField_65 = new JTextField();
		textField_65.setText(" ");
		textField_65.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_65.setColumns(10);
		textField_65.setBounds(836, 233, 42, 43);
		frame.getContentPane().add(textField_65);
		
		JButton button = new JButton("FINISH");
		button.setFont(new Font("Tahoma", Font.BOLD, 24));
		button.setBounds(312, 829, 179, 42);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("GIVE UP!");
		button_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		button_1.setBounds(736, 829, 167, 42);
		frame.getContentPane().add(button_1);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1320, 1020);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(895, 562, 56, 16);
		panel.add(lblNewLabel);
	}
}
