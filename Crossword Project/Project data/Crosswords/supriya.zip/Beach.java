package com.myproject.UI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JButton;

public class Beach {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField txtA;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField txtU;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField txtW;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField txtN;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField txtL;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField txtF;
	private JTextField textField_34;
	private JTextField textField_35;
	private JTextField textField_36;
	private JTextField textField_37;
	private JTextField textField_38;
	private JTextField textField_39;
	private JTextField textField_40;
	private JTextField textField_41;
	private JTextField textField_42;
	private JTextField textField_43;
	private JTextField textField_44;
	private JTextField textField_45;
	private JTextField textField_46;
	private JTextField textField_47;
	private JTextField textField_48;
	private JTextField txtS;
	private JTextField textField_50;
	private JTextField textField_51;
	private JTextField textField_52;
	private JTextField textField_53;
	private JTextField txtG;
	private JTextField textField_55;
	private JTextField textField_56;
	private JTextField textField_57;
	private JTextField textField_58;
	private JTextField textField_59;
	private JTextField textField_60;
	private JTextField textField_61;
	private JTextField textField_62;
	private JTextField textField_63;
	private JTextField txtU_1;
	private JTextField textField_65;
	private JTextField textField_66;
	private JTextField textField_67;
	private JTextField textField_68;
	private JTextField txtE;
	private JTextField textField_70;
	private JTextField textField_71;
	private JTextField textField_72;
	private JTextField textField_73;
	private JTextField textField_74;
	private JTextField textField_75;
	private JTextField textField_76;
	private JTextField txtB;
	private JTextField textField_78;
	private JTextField textField_79;
	private JTextField textField_80;
	private JTextField txtO;
	private JTextField textField_82;
	private JTextField textField_83;
	private JTextField textField_84;
	private JTextField textField_85;
	private JTextField textField_86;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Beach window = new Beach();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Beach() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField.setColumns(10);
		textField.setBounds(162, 125, 42, 43);
		frame.getContentPane().add(textField);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_1.setColumns(10);
		textField_1.setBounds(203, 125, 42, 43);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_2.setColumns(10);
		textField_2.setBounds(245, 125, 42, 43);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_3.setColumns(10);
		textField_3.setBounds(286, 125, 42, 43);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_4.setColumns(10);
		textField_4.setBounds(327, 125, 42, 43);
		frame.getContentPane().add(textField_4);
		
		txtA = new JTextField();
		txtA.setEnabled(false);
		txtA.setText(" A");
		txtA.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtA.setColumns(10);
		txtA.setBounds(368, 125, 42, 43);
		frame.getContentPane().add(txtA);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_6.setColumns(10);
		textField_6.setBounds(409, 125, 42, 43);
		frame.getContentPane().add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_7.setColumns(10);
		textField_7.setBounds(451, 125, 42, 43);
		frame.getContentPane().add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_8.setColumns(10);
		textField_8.setBounds(493, 125, 42, 43);
		frame.getContentPane().add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_9.setColumns(10);
		textField_9.setBounds(535, 125, 42, 43);
		frame.getContentPane().add(textField_9);
		
		txtU = new JTextField();
		txtU.setEnabled(false);
		txtU.setText(" U");
		txtU.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtU.setColumns(10);
		txtU.setBounds(245, 82, 42, 43);
		frame.getContentPane().add(txtU);
		
		textField_11 = new JTextField();
		textField_11.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_11.setColumns(10);
		textField_11.setBounds(245, 166, 42, 43);
		frame.getContentPane().add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_12.setColumns(10);
		textField_12.setBounds(245, 210, 42, 43);
		frame.getContentPane().add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_13.setColumns(10);
		textField_13.setBounds(245, 254, 42, 43);
		frame.getContentPane().add(textField_13);
		
		txtW = new JTextField();
		txtW.setEnabled(false);
		txtW.setText(" W");
		txtW.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtW.setColumns(10);
		txtW.setBounds(245, 296, 42, 43);
		frame.getContentPane().add(txtW);
		
		textField_15 = new JTextField();
		textField_15.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_15.setColumns(10);
		textField_15.setBounds(245, 339, 42, 43);
		frame.getContentPane().add(textField_15);
		
		textField_16 = new JTextField();
		textField_16.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_16.setColumns(10);
		textField_16.setBounds(245, 383, 42, 43);
		frame.getContentPane().add(textField_16);
		
		textField_17 = new JTextField();
		textField_17.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_17.setColumns(10);
		textField_17.setBounds(245, 427, 42, 43);
		frame.getContentPane().add(textField_17);
		
		textField_18 = new JTextField();
		textField_18.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_18.setColumns(10);
		textField_18.setBounds(245, 471, 42, 43);
		frame.getContentPane().add(textField_18);
		
		textField_19 = new JTextField();
		textField_19.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_19.setColumns(10);
		textField_19.setBounds(162, 166, 42, 43);
		frame.getContentPane().add(textField_19);
		
		txtN = new JTextField();
		txtN.setEnabled(false);
		txtN.setText(" N");
		txtN.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtN.setColumns(10);
		txtN.setBounds(162, 210, 42, 43);
		frame.getContentPane().add(txtN);
		
		textField_21 = new JTextField();
		textField_21.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_21.setColumns(10);
		textField_21.setBounds(162, 254, 42, 43);
		frame.getContentPane().add(textField_21);
		
		textField_22 = new JTextField();
		textField_22.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_22.setColumns(10);
		textField_22.setBounds(162, 296, 42, 43);
		frame.getContentPane().add(textField_22);
		
		textField_23 = new JTextField();
		textField_23.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_23.setColumns(10);
		textField_23.setBounds(162, 339, 42, 43);
		frame.getContentPane().add(textField_23);
		
		textField_24 = new JTextField();
		textField_24.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_24.setColumns(10);
		textField_24.setBounds(203, 471, 42, 43);
		frame.getContentPane().add(textField_24);
		
		textField_25 = new JTextField();
		textField_25.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_25.setColumns(10);
		textField_25.setBounds(162, 471, 42, 43);
		frame.getContentPane().add(textField_25);
		
		txtL = new JTextField();
		txtL.setEnabled(false);
		txtL.setText(" L");
		txtL.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtL.setColumns(10);
		txtL.setBounds(162, 512, 42, 43);
		frame.getContentPane().add(txtL);
		
		textField_27 = new JTextField();
		textField_27.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_27.setColumns(10);
		textField_27.setBounds(162, 552, 42, 43);
		frame.getContentPane().add(textField_27);
		
		textField_28 = new JTextField();
		textField_28.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_28.setColumns(10);
		textField_28.setBounds(162, 594, 42, 43);
		frame.getContentPane().add(textField_28);
		
		textField_29 = new JTextField();
		textField_29.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_29.setColumns(10);
		textField_29.setBounds(162, 637, 42, 43);
		frame.getContentPane().add(textField_29);
		
		textField_30 = new JTextField();
		textField_30.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_30.setColumns(10);
		textField_30.setBounds(493, 82, 42, 43);
		frame.getContentPane().add(textField_30);
		
		textField_31 = new JTextField();
		textField_31.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_31.setColumns(10);
		textField_31.setBounds(493, 166, 42, 43);
		frame.getContentPane().add(textField_31);
		
		textField_32 = new JTextField();
		textField_32.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_32.setColumns(10);
		textField_32.setBounds(493, 210, 42, 43);
		frame.getContentPane().add(textField_32);
		
		txtF = new JTextField();
		txtF.setText(" F");
		txtF.setEnabled(false);
		txtF.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtF.setColumns(10);
		txtF.setBounds(493, 254, 42, 43);
		frame.getContentPane().add(txtF);
		
		textField_34 = new JTextField();
		textField_34.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_34.setColumns(10);
		textField_34.setBounds(493, 296, 42, 43);
		frame.getContentPane().add(textField_34);
		
		textField_35 = new JTextField();
		textField_35.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_35.setColumns(10);
		textField_35.setBounds(493, 339, 42, 43);
		frame.getContentPane().add(textField_35);
		
		textField_36 = new JTextField();
		textField_36.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_36.setColumns(10);
		textField_36.setBounds(493, 383, 42, 43);
		frame.getContentPane().add(textField_36);
		
		textField_37 = new JTextField();
		textField_37.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_37.setColumns(10);
		textField_37.setBounds(451, 254, 42, 43);
		frame.getContentPane().add(textField_37);
		
		textField_38 = new JTextField();
		textField_38.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_38.setColumns(10);
		textField_38.setBounds(409, 254, 42, 43);
		frame.getContentPane().add(textField_38);
		
		textField_39 = new JTextField();
		textField_39.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_39.setColumns(10);
		textField_39.setBounds(368, 254, 42, 43);
		frame.getContentPane().add(textField_39);
		
		textField_40 = new JTextField();
		textField_40.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_40.setColumns(10);
		textField_40.setBounds(368, 296, 42, 43);
		frame.getContentPane().add(textField_40);
		
		textField_41 = new JTextField();
		textField_41.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_41.setColumns(10);
		textField_41.setBounds(327, 296, 42, 43);
		frame.getContentPane().add(textField_41);
		
		textField_42 = new JTextField();
		textField_42.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_42.setColumns(10);
		textField_42.setBounds(286, 296, 42, 43);
		frame.getContentPane().add(textField_42);
		
		textField_43 = new JTextField();
		textField_43.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_43.setColumns(10);
		textField_43.setBounds(535, 254, 42, 43);
		frame.getContentPane().add(textField_43);
		
		textField_44 = new JTextField();
		textField_44.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_44.setColumns(10);
		textField_44.setBounds(576, 254, 42, 43);
		frame.getContentPane().add(textField_44);
		
		textField_45 = new JTextField();
		textField_45.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_45.setColumns(10);
		textField_45.setBounds(618, 254, 42, 43);
		frame.getContentPane().add(textField_45);
		
		textField_46 = new JTextField();
		textField_46.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_46.setColumns(10);
		textField_46.setBounds(576, 210, 42, 43);
		frame.getContentPane().add(textField_46);
		
		textField_47 = new JTextField();
		textField_47.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_47.setColumns(10);
		textField_47.setBounds(576, 296, 42, 43);
		frame.getContentPane().add(textField_47);
		
		textField_48 = new JTextField();
		textField_48.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_48.setColumns(10);
		textField_48.setBounds(368, 339, 42, 43);
		frame.getContentPane().add(textField_48);
		
		txtS = new JTextField();
		txtS.setEnabled(false);
		txtS.setText(" S");
		txtS.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtS.setColumns(10);
		txtS.setBounds(368, 383, 42, 43);
		frame.getContentPane().add(txtS);
		
		textField_50 = new JTextField();
		textField_50.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_50.setColumns(10);
		textField_50.setBounds(368, 427, 42, 43);
		frame.getContentPane().add(textField_50);
		
		textField_51 = new JTextField();
		textField_51.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_51.setColumns(10);
		textField_51.setBounds(368, 471, 42, 43);
		frame.getContentPane().add(textField_51);
		
		textField_52 = new JTextField();
		textField_52.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_52.setColumns(10);
		textField_52.setBounds(327, 471, 42, 43);
		frame.getContentPane().add(textField_52);
		
		textField_53 = new JTextField();
		textField_53.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_53.setColumns(10);
		textField_53.setBounds(409, 471, 42, 43);
		frame.getContentPane().add(textField_53);
		
		txtG = new JTextField();
		txtG.setEnabled(false);
		txtG.setText(" G");
		txtG.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtG.setColumns(10);
		txtG.setBounds(451, 471, 42, 43);
		frame.getContentPane().add(txtG);
		
		textField_55 = new JTextField();
		textField_55.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_55.setColumns(10);
		textField_55.setBounds(493, 471, 42, 43);
		frame.getContentPane().add(textField_55);
		
		textField_56 = new JTextField();
		textField_56.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_56.setColumns(10);
		textField_56.setBounds(535, 471, 42, 43);
		frame.getContentPane().add(textField_56);
		
		textField_57 = new JTextField();
		textField_57.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_57.setColumns(10);
		textField_57.setBounds(576, 471, 42, 43);
		frame.getContentPane().add(textField_57);
		
		textField_58 = new JTextField();
		textField_58.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_58.setColumns(10);
		textField_58.setBounds(368, 512, 42, 43);
		frame.getContentPane().add(textField_58);
		
		textField_59 = new JTextField();
		textField_59.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_59.setColumns(10);
		textField_59.setBounds(368, 552, 42, 43);
		frame.getContentPane().add(textField_59);
		
		textField_60 = new JTextField();
		textField_60.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_60.setColumns(10);
		textField_60.setBounds(409, 552, 42, 43);
		frame.getContentPane().add(textField_60);
		
		textField_61 = new JTextField();
		textField_61.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_61.setColumns(10);
		textField_61.setBounds(451, 552, 42, 43);
		frame.getContentPane().add(textField_61);
		
		textField_62 = new JTextField();
		textField_62.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_62.setColumns(10);
		textField_62.setBounds(493, 552, 42, 43);
		frame.getContentPane().add(textField_62);
		
		textField_63 = new JTextField();
		textField_63.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_63.setColumns(10);
		textField_63.setBounds(535, 552, 42, 43);
		frame.getContentPane().add(textField_63);
		
		txtU_1 = new JTextField();
		txtU_1.setEnabled(false);
		txtU_1.setText(" U");
		txtU_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtU_1.setColumns(10);
		txtU_1.setBounds(576, 552, 42, 43);
		frame.getContentPane().add(txtU_1);
		
		textField_65 = new JTextField();
		textField_65.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_65.setColumns(10);
		textField_65.setBounds(618, 552, 42, 43);
		frame.getContentPane().add(textField_65);
		
		textField_66 = new JTextField();
		textField_66.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_66.setColumns(10);
		textField_66.setBounds(659, 552, 42, 43);
		frame.getContentPane().add(textField_66);
		
		textField_67 = new JTextField();
		textField_67.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_67.setColumns(10);
		textField_67.setBounds(701, 552, 42, 43);
		frame.getContentPane().add(textField_67);
		
		textField_68 = new JTextField();
		textField_68.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_68.setColumns(10);
		textField_68.setBounds(409, 594, 42, 43);
		frame.getContentPane().add(textField_68);
		
		txtE = new JTextField();
		txtE.setEnabled(false);
		txtE.setText(" E");
		txtE.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtE.setColumns(10);
		txtE.setBounds(409, 637, 42, 43);
		frame.getContentPane().add(txtE);
		
		textField_70 = new JTextField();
		textField_70.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_70.setColumns(10);
		textField_70.setBounds(368, 637, 42, 43);
		frame.getContentPane().add(textField_70);
		
		textField_71 = new JTextField();
		textField_71.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_71.setColumns(10);
		textField_71.setBounds(327, 637, 42, 43);
		frame.getContentPane().add(textField_71);
		
		textField_72 = new JTextField();
		textField_72.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_72.setColumns(10);
		textField_72.setBounds(451, 637, 42, 43);
		frame.getContentPane().add(textField_72);
		
		textField_73 = new JTextField();
		textField_73.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_73.setColumns(10);
		textField_73.setBounds(493, 637, 42, 43);
		frame.getContentPane().add(textField_73);
		
		textField_74 = new JTextField();
		textField_74.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_74.setColumns(10);
		textField_74.setBounds(701, 512, 42, 43);
		frame.getContentPane().add(textField_74);
		
		textField_75 = new JTextField();
		textField_75.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_75.setColumns(10);
		textField_75.setBounds(701, 471, 42, 43);
		frame.getContentPane().add(textField_75);
		
		textField_76 = new JTextField();
		textField_76.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_76.setColumns(10);
		textField_76.setBounds(701, 427, 42, 43);
		frame.getContentPane().add(textField_76);
		
		txtB = new JTextField();
		txtB.setEnabled(false);
		txtB.setText(" B");
		txtB.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtB.setColumns(10);
		txtB.setBounds(701, 383, 42, 43);
		frame.getContentPane().add(txtB);
		
		textField_78 = new JTextField();
		textField_78.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_78.setColumns(10);
		textField_78.setBounds(701, 339, 42, 43);
		frame.getContentPane().add(textField_78);
		
		textField_79 = new JTextField();
		textField_79.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_79.setColumns(10);
		textField_79.setBounds(701, 296, 42, 43);
		frame.getContentPane().add(textField_79);
		
		textField_80 = new JTextField();
		textField_80.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_80.setColumns(10);
		textField_80.setBounds(701, 254, 42, 43);
		frame.getContentPane().add(textField_80);
		
		txtO = new JTextField();
		txtO.setEnabled(false);
		txtO.setText(" O");
		txtO.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		txtO.setColumns(10);
		txtO.setBounds(701, 210, 42, 43);
		frame.getContentPane().add(txtO);
		
		textField_82 = new JTextField();
		textField_82.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_82.setColumns(10);
		textField_82.setBounds(701, 166, 42, 43);
		frame.getContentPane().add(textField_82);
		
		textField_83 = new JTextField();
		textField_83.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_83.setColumns(10);
		textField_83.setBounds(701, 125, 42, 43);
		frame.getContentPane().add(textField_83);
		
		textField_84 = new JTextField();
		textField_84.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_84.setColumns(10);
		textField_84.setBounds(659, 383, 42, 43);
		frame.getContentPane().add(textField_84);
		
		textField_85 = new JTextField();
		textField_85.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_85.setColumns(10);
		textField_85.setBounds(618, 383, 42, 43);
		frame.getContentPane().add(textField_85);
		
		textField_86 = new JTextField();
		textField_86.setFont(new Font("Perpetua Titling MT", Font.BOLD, 24));
		textField_86.setColumns(10);
		textField_86.setBounds(576, 383, 42, 43);
		frame.getContentPane().add(textField_86);
		
		JButton button = new JButton("FINISH");
		button.setFont(new Font("Tahoma", Font.BOLD, 24));
		button.setBounds(255, 824, 179, 42);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("GIVE UP!");
		button_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		button_1.setBounds(623, 824, 167, 42);
		frame.getContentPane().add(button_1);
	}

}
